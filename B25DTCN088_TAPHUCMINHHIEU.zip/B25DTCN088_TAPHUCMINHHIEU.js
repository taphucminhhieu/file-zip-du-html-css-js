function updateClock() {
    const now = new Date();
    const time = now.toLocaleTimeString("vi-VN", { hour12: false });

    document.getElementById("clock").textContent = time;
    document.getElementById("footerClock").textContent = time;
}

function showWelcomeMessage() {
    const now = new Date();
    const date = now.toLocaleDateString("vi-VN");

    alert("Hôm nay là ngày " + date + ", chào mừng bạn đến với trang của Tạ Phúc Minh Hiếu!");
}

const avatarButton = document.getElementById("avatarButton");
const imageModal = document.getElementById("imageModal");
const closeModal = document.getElementById("closeModal");

avatarButton.addEventListener("click", function () {
    imageModal.classList.add("active");
    imageModal.setAttribute("aria-hidden", "false");
});

function hideImageModal() {
    imageModal.classList.remove("active");
    imageModal.setAttribute("aria-hidden", "true");
}

closeModal.addEventListener("click", hideImageModal);

imageModal.addEventListener("click", function (event) {
    if (event.target === imageModal) {
        hideImageModal();
    }
});

document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") {
        hideImageModal();
    }
});

const toggleHobbies = document.getElementById("toggleHobbies");
const extraHobbies = document.querySelectorAll(".extra-hobby");

toggleHobbies.addEventListener("click", function () {
    let isExpanded = toggleHobbies.textContent === "Thu gọn";

    extraHobbies.forEach(function (hobby) {
        hobby.classList.toggle("show", !isExpanded);
    });

    if (isExpanded) {
        toggleHobbies.textContent = "Xem thêm";
    } else {
        toggleHobbies.textContent = "Thu gọn";
    }
});

document.getElementById("year").textContent = new Date().getFullYear();

updateClock();
setInterval(updateClock, 1000);
window.addEventListener("load", showWelcomeMessage);
